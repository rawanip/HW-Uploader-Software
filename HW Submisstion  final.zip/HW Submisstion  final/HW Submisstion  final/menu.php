<?php
 // get user name for menue
include('session.php');
$status=$_SESSION['status'];
$username=$_SESSION['username'];
include 'connectdb.php';

$q="select name from student where username='$username'";

$result=mysql_query($q, $connection);

$row = mysql_fetch_assoc($result);

$name =$row['name'];
///////////

?>