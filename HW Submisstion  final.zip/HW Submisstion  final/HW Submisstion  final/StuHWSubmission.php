<?php
include('session.php');
$status=$_SESSION['status'];
$username=$_SESSION['username'];

include 'connectdb.php';

//get student name
$q="select name from student where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];

//get student id
$qid="select sID from student where username='$username'";
$resultid=mysql_query($qid, $connection);
$rowid = mysql_fetch_assoc($resultid);
$id =$rowid['sID'];

//get student email
$qemail="select email from student where username='$username'";
$resultemail=mysql_query($qemail, $connection);
$rowemail = mysql_fetch_assoc($resultemail);
$email =$rowemail['email'];


//get hw information
$hwid=$_GET['ID'];
$q1="select * from homework where hID=".$hwid;
$result1=mysql_query($q1, $connection);
$row1 = mysql_fetch_assoc($result1);
$title =$row1['title'];
$description =$row1['description'];
$deadline =$row1['deadline'];




?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $title; ?> submission</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="header-right">
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
          
                <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>


            </div>
        
            <div class="navbar-header">
             
                <a class="navbar-brand" href="StudentHomePage.php">HomeWork Submissions System </a>
            </div>

            <div class="header-right">

               
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->


	  
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="student.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="stuchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="stuchangepassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
                  
              
                    <li>
                        <a href="StuAllCourses.php"><i ></i>View Courses </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href="StuAddCourse.php"><i ></i>Add Course</a>
                    </li>
					
					
				
					
					
                     <li>
                        <a href="SearchHwStu.php"><i ></i>Search for Homework</a>
                    </li>
                   
               
                     
                   <li>
                        <a href="StuViewSubmitted.php"><i ></i>View Submitted Homeworks</a>
                    </li>
                    
                </ul>
            </div>

        </nav>
	  
      
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"><?php echo $title; ?> Submission page</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                                

                     
                                  
                                  <div class="panel panel-info">
                        <div class="panel-heading"><?php echo $title; ?>
                                             </div>
                        <div class="panel-body">
                            <form role="form" action="#submit" method="post" enctype="multipart/form-data">
                                      
                                       
                                            <div class="form-group">
                                            <label>Description:<?php echo $description; ?><br>
         
                                            Deadline:<?php echo $deadline; ?></label>
                                            <textarea name="comment" class="form-control" rows="3"></textarea>
                                            <div>
                        <div><label for="image_file">Please select file</label></div>
                    <input type="file" id="userfile" name="userfile">
                    </div></div>                           
                                        
<input class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal" type="submit" name="upload" value="Submit">
<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal"><a href="Studenthomepage.php" style="text-decoration:none; color:white;">Cancel</a></button>
                                    </form>
                                    
                                    
                                    
                                    
                       <div id="submit"><?php
                        
                          if(isset($_POST['upload'])){  
                              //get comment
                              $comment="";
                              if($_POST['comment'])
                                 $comment=$_POST['comment'];                                                                               
                            
                              //get file
                              if($_FILES['userfile']['size']>0){
                                    
    
                                  $target_dir = "uploads/";
                                  $target_file = $target_dir . basename($_FILES["userfile"]["name"]);
                                            
                                  if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)){
                                        
                                    
                                  $res1=mysql_query(" UPDATE homework SET  date = CURRENT_TIMESTAMP() WHERE hID = '".$hwid."'", $connection);   
							      $res2=mysql_query(" UPDATE homework SET comment = '$comment' WHERE hID = '".$hwid."'", $connection);
                                  $res3=mysql_query(" UPDATE homework SET studentfile = '$target_file'  WHERE hID = '".$hwid."'");

                                  if(!$res3)
								       echo " <p class='help-block' style='color:red;'>the type of file you selected is not allowed</p>";
								       else echo " <p class='help-block'>your file submitted successfully</p>";								    								    
                                   
                                         }//end move_uploaded_file
                                    
                                    
                                    
                                    
                                    
                                    
//sending email    
                               
 require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;
$mail->isSMTP();                                 // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';                  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                          // Enable SMTP authentication
$mail->Username = '*************@gmail.com';     // SMTP username
$mail->Password = '*********';                   // SMTP password
$mail->SMTPSecure = 'tls';                       // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                               // TCP port to connect to


$mail->addAddress($email);   // Add a recipient

$mail->isHTML(true);  // Set email format to HTML

$bodyContent  = '<h1>Hi '.$name.',';
$bodyContent .= '<p>you have successfully submit '.$title.' with the following information:';
$bodyContent .= '<p>homework title:'.$title;
$bodyContent .= '<p>submitted file:in the attatchment';
$bodyContent .= '<p>comment:'.$comment;
$bodyContent .= '<p>submission date:'.date("Y-m-d");


$mail->Subject = $title.' confirmation';
$mail->Body    = $bodyContent;
$mail->addAttachment($target_file,$_FILES["userfile"]["name"]);
if(!$mail->send()) {
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo '<p class="help-block">An email with submission information has been sent</p>';
}  
                                    
                                    
                                    
                                    
                              }//end if($_FILES['userfile']['size']>0)
                    else echo "<p style='color:red;'>Please select a file</p>";
               }//end if(isset($_POST['upload']))
                               
                              
                               
                                    
                           ?>
                           </div>
                                    
                            </div>
                        </div>
            

                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                             

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />                    
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>