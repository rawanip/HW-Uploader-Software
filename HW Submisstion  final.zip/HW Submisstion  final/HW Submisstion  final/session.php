<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter

include 'connectdb.php';



session_start();// Starting Session

// Storing Session
$username=$_SESSION['username'];
$status=$_SESSION['status'];

// SQL Query To Fetch Complete Information Of User
if($status=='Student')
$q="select username from student where username='$username'";
else if($status=='Teacher') $q="select username from teacher where username='$username'";


$ses_sql=mysql_query($q, $connection);

$row = mysql_fetch_assoc($ses_sql);

$login_session =$row['username'];
if(!isset($login_session)){
mysql_close($connection); // Closing Connection
if($status=='Student')
header('Location: Studenthomepage.php');
else if($status=='Teacher')
header('Location: index.php');  // Redirecting To Home Page
}
?>