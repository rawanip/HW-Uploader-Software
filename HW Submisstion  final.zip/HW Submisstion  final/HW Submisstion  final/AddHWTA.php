<?php
include'session.php';
$status=$_SESSION['status'];
$username=$_SESSION['username']; 
include 'connectdb.php';


$q="SELECT *  FROM `teacher` where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];

  if (isset($_GET))
  {
   $IDC= $_GET["cid"];
  }
 $qc="SELECT *FROM course WHERE ID= $IDC";
 $resultc=mysql_query($qc, $connection);
$rowc= mysql_fetch_assoc($resultc);
  
  

$IDT =$row['tID'];

$message="";
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add HOMEWORK</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
		<div class="header-right">

          
                <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>


            </div>
        
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
				<a class="navbar-brand" href="teacherHomephp.php">Home Work System Submissions</a>
            </div>
			   <div class="header-right">
			   
            </div>
        </nav>
        <!-- /. NAV TOP  -->
		 
                <!-- /. NAV TOP  -->
        <!-- /. NAV TOP  -->
		 
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="teacher.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>
  <li>
                        <a  href="teacherHomephp.php"><i ></i>Home</a>
                    </li>

                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="tchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="tchangpassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
					
                  
              
                    <li>
                        <a href="addCoursTeacher.php"><i ></i>Add Course </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href=""><i ></i>View Statictcs</a>
                    </li>
					
						
				 <li>
                        <a href="teacherCorsess.php"><i ></i>View All Courses</a>
                    </li>
				
					
					
                    
                   
               
                   
                    
                </ul>
            </div>

        </nav>
        <!-- /. NAV TOP  -->
      
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">ADD HOMEWOEK</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->
               <form role="form" action="#ADDHW" method="POST"enctype="multipart/form-data" >
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                                <div id="reviews" class="carousel slide" data-ride="carousel">

                                    <div class="form-group input-group">
										<input name="title"class="form-control" placeholder="Title" type = "text" >
                                        </div>
										
										<div class="form-group input-group">
										<textarea name="Description" class="form-control"  rows = "4" cols= "36">Description</textarea>
                                        </div>
										
										
										<div class="form-group input-group">
										Dead Line
										Date:
										<input name = "deadlineDate" type = "date"  >
										</div >
										<div class="form-group input-group">
										
										<!-- time:
										<input name = "deadlinetime" type = "time"  >
										<br>
										<br> -->
										
										     <div>
                        <div><label for="image_file">Please select file</label></div>
						<input type="hidden" name="MAX_FILE_SIZE" value="2000000">
                    <input name="userfile" type="file" id="userfile"> 
<div id="ADDHW">
 <?php
  if(isset($_POST['submit'])) 
	{ 
	 if(!empty($_POST['title'])&& !empty($_POST['Description'])&&  !empty($_POST['deadlineDate'])&&  $_FILES['userfile']['size'] > 0)
	 {										
         $target_dir = "uploads/";
         $target_file = $target_dir . basename($_FILES["userfile"]["name"]);
    if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file))
		{
								   $title =  $_POST['title'];
								  $Description = $_POST['Description'];
								  $deadlineDate =  $_POST['deadlineDate'];
								  
		  $qS = "SELECT sID FROM studentcourses WHERE cID='$IDC'";
			if( $resultS=mysql_query($qS, $connection))
			 {
				 if(mysql_num_rows($resultS)>0)
	  				{ 
					  while( $row = mysql_fetch_array( $resultS))
					  {
						 $IDS= $row["sID"];
						  mysql_query( "
						INSERT INTO `homework`(`hID`, `cID`, `sID`, `title`, `description`, `deadline`, `filename`, `comment`, `grade`, `studentfile`, `date`) VALUES('','$IDC','$IDS','$title', '$Description' , '$deadlineDate' ,' $target_file', '', '', '', '' )"); 
						
                         $UpdateMessage='new hw uplouded in course ';
				         $UpdateMessage.=$rowc['title'];
						 $q=mysql_query(" INSERT INTO `updates`(`sID`, `tID`, `message`) VALUES ('$IDS','$IDT',' $UpdateMessage')");
											  
                         $message=" the HOMEWOEK Added succussfully...";

					  }//end while
                                         
										   
					}//end if row not empty
				}//end if result
		}//end if tmp_name
	else
 $message="some field are empty..";
									
	}// end if is set
	}
/* 	mysql_close($connection );
 */?>	
								 </div > 
								 <br><br>
 <p class="help-block"><?php print $message; ?></p>
                   

                                        <div class="header-right">
										<button name="submit"  type="submit"alue = "submission" class="btn btn-success"  data-toggle="modal" data-target="#myModal">ADD</button>
										</div >
										
											 </div>
                                    <!--INDICATORS-->
									
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>
</form>

									</div>
                                    
							</div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>