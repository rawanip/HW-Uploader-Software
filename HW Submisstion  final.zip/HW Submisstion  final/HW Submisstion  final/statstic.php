﻿<?php
include'session.php';
$status=$_SESSION['status'];
$username=$_SESSION['username']; 
include 'connectdb.php';


$q="SELECT *  FROM `teacher` where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];
$id =$row['tID'];

//select course id 
$qC="SELECT cID  FROM `teachercourses` where tID='$id'";
$resultC=mysql_query($qC, $connection);
$years=year();
echo
" <script>
$(function () {
    Highcharts.chart('container', {
        title: {
            text: 'Avarge HomeWork Grade for the previous Semesteres',
            x: -20 //center
        },
        
        xAxis: {
            categories: [$years]
        },
        yAxis: {
            title: {
                text: 'Grade '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: '°C'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
			" $QYEAR="SELECT title FROM course WHERE ID='$idC' ";
   	          $resultY = mysql_query($QYEAR, $connection);
			  
	          $QYEARG="SELECT grade FROM homework WHERE ID='$idC'";
   	          $resultG = mysql_query($QYEARG, $connection);
		
		while(mysql_fetch_array($resultY) >0{
		  ."name: '"
         while($rowY=mysql_fetch_array($resultY) )
		 {
            .$rowY['title']."',
            data:[ "
			$i=0;
			$sum=0;
			while($rowG=mysql_fetch_array($resultG)
			{ $sum=$sum+$rowG['grade'];
			  $i=$i+1;
			  }
		 .$sum/$i."]}'
		 }
           
        }]
    });
});
</script>";
function fillArrray(){
 
 $array;
 if(mysql_num_rows($resultC)>0)
	 { 
	   while( $rowC = mysql_fetch_array( $resultC))
		   $idC=$rowC['cID'];
		}
}

function year()
{
	$arrayY;
    global $resultC;
	global$q;
	global$connection;
    $ReturnArr="";
	$curryear=date("Y");
	$arrayY=array();
 $i=0;
	if(mysql_num_rows($resultC)>0)
	{ 
      
      while( $rowC = mysql_fetch_array( $resultC))
	  {
	    $idC=$rowC['cID'];
	    $flag=false;
		
	   //select all the years from table courses that less than 2016
	     $QYEAR="SELECT year FROM course WHERE ID='$idC' AND year<$curryear";
   	     $resultY = mysql_query($QYEAR, $connection);
	    
		
		 
         while($rowY=mysql_fetch_array($resultY) )
		 {
			 for($j=0;$j<count($arrayY);$j++)
			 {
				 if( $arrayY[$j]==$rowY['year'])
					 $flag=true;
			 }
				 if(!$flag)
				 {
		           $arrayY[$i]=$rowY['year'];
				 
				 }
				 
				 $i=$i+1;
				   
			 }
			 
			 
		 }
	}
	
	
	
	for($i=0;$i<count( $arrayY);$i++)
	 {    
         $Y=$arrayY[$i];
       if($i!=count( $arrayY)-1){
		 
	   $ReturnArr.="'$Y',";  }
	   else
		 $ReturnArr.="'$Y'";
	  }
	 
	 
	return $ReturnArr;


}

?>