<?php
include('loginphp.php'); // Includes Login Script

if(isset($_SESSION['username'])){

  if(isset($_SESSION['status'])){
    if($_SESSION['status']=='Teacher')
       {header("location: teacherHomephp.php");}
    else {header("location: Studenthomepage.php");}
  }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="homepage.html">Homework Submission System </a>
            </div>

            <div class="header-right">

           

            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                  
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Loging </h1>
                        <h1 class="page-subhead-line">Enter your information to Login </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                            </div>
							
							
							
							
							
<div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           Login
                        </div>
                        <div class="panel-body">
                            <form role="form" method="post">
                       <p class="help-block"><?php print $error; ?></p>
                       
                                 <div class="form-group">
								 
								   
								 
								   <label>Enter UserName </label>
                                            <input class="form-control" type="text" name = "username">
								 
								 
								 
                                            <label>Enter Password</label>
                                            <input class="form-control" type="password" name = "password">
                                        </div>
                               
                               
							   
							          <div class="form-group input-group">
                                        Status:<select class="form-control" name = "status" >
										<option selected>Student</option>
										<option>Teacher</option></select>	</div >	
							   
							   
                                 
                                        <button type="submit" name="submit" class="btn btn-danger">Login </button>
<p class="help-block">Not register ? <a href="singUp.html" >click here </a> </p>
                                    </form>
                            </div>
                        </div>
                            </div>
        </div>
             <!--/.ROW-->
            
			
			
			
    <div id="footer-sec">
        &copy; 2016 Homework Submission System  
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
