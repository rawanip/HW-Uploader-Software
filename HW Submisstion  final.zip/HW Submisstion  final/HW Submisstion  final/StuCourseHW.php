<?php
include('session.php');
$status=$_SESSION['status'];
$username=$_SESSION['username'];

include 'connectdb.php';
//get student name
$q="select name from student where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];

//get student id
$qid="select sID from student where username='$username'";
$resultid=mysql_query($qid, $connection);
$rowid = mysql_fetch_assoc($resultid);
$id =$rowid['sID'];

//get course title
$cid=$_GET['ID'];
$q1="select title from course where ID=".$cid;
$result1=mysql_query($q1, $connection);
$row1 = mysql_fetch_assoc($result1);
$coursetitle =$row1['title'];

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $coursetitle." homeworks"; ?> </title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
      $(document).ready(function(){
    $(".help-block").css("color","red");
    $(".help-block").css("font-size","12px");
    });
</script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        
        <div class="header-right">
           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>

            </div>
            <div class="navbar-header">

                <a class="navbar-brand" href="StudentHomePage.php">HomeWork Submissions System </a>
            </div>

            <div class="header-right">            

            </div>
        </nav>
        <!-- /. NAV TOP  -->
       
	  
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="student.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="stuchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="stuchangepassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
                  
              
                    <li>
                        <a href="StuAllCourses.php"><i ></i>View Courses </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href="StuAddCourse.php"><i ></i>Add Course</a>
                    </li>
					
					
				
					
					
                     <li>
                        <a href="SearchHwStu.php"><i ></i>Search for Homework</a>
                    </li>
                   
               
                     
                   <li>
                        <a href="StuViewSubmitted.php"><i ></i>View Submitted Homeworks</a>
                    </li>
                    
                </ul>
            </div>

        </nav>
	  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"><?php  echo $coursetitle; ?> Homeworks</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                              

                                  
										<div class="form-group input-group">
										
                            <div><br><br>
							<?php
							
							$query="select hID,title,deadline,date from homework where sID='".$id."' AND cID='".$cid."'";
                            $result=mysql_query($query, $connection);
                            if(mysql_num_rows($result)==0)
                            echo "<p class='help-block'>No homeworks</p>";
                            else {
                            while($row = mysql_fetch_row($result)){
                            $title=$row[1];
                            $hid=$row[0];
                                                         
                                echo "<div class='panel panel-default'>";
                                echo "<div class='panel-heading'>";
                                echo "".$title;
                                echo "</div>";
                                echo "<div class='panel-body'>";
                                echo "<a href='HwStu.php?ID=".$hid."' target='_blank'>view this homeworks description </a><br>";
                                if($row[2]<$row[3])
                                     echo "<p class='help-block'>Sumbitted after the deadline</p>";
                                     else echo "<br>";
                                echo "<button type='button' class='btn btn-sm btn-success'><a href='StuHWSubmission.php?ID=".$hid."' style='text-decoration:none; color:white;'>";
                                if($row[3]=="0000-00-00")
                                     echo "Submit";
                                     else echo "Resubmit";
                                echo "</a></button>";
                                echo "<span>  </span><button type='button' class='btn btn-sm btn-success'><a href='HwStuDetails.php?ID=".$hid."' target='_blank' style='text-decoration:none; color:white;'>details</a></button>";

                                
                                echo "</div></div>";
                                 
                                                       }  
                                                         
                                                         }

							?>


                                
                                


                        </div>
								 </div>
  
                                    

                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                               <br><br>
                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>

<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal"><a href="StudentHomePage.php" style="text-decoration:none; color:white;">Back To Homepage</a></button>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>