<?php
include('session.php');

$status=$_SESSION['status'];
$username=$_SESSION['username'];

include 'connectdb.php';
//get student name
$q="select name from student where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];

$q="select sID from student where username='$username'";

$result=mysql_query($q, $connection);

$row = mysql_fetch_assoc($result);

$id =$row['sID'];
$message="";
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ADD COURSE </title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="StudentHomePage.php">HomeWork Submissions System </a>
            </div>

            <div class="header-right">

                               <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>

				

            </div>
        </nav>
        

        
        <!-- /. NAV TOP  -->
      
      
	  
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="student.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="stuchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="stuchangepassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
                  
              
                    <li>
                        <a href="StuAllCourses.php"><i ></i>View Courses </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href="StuAddCourse.php"><i ></i>Add Course</a>
                    </li>
					
					
				
					
					
                     <li>
                        <a href="SearchHwStu.php"><i ></i>Search for Homework</a>
                    </li>
                   
               
                     
                   <li>
                        <a href="StuViewSubmitted.php"><i ></i>View Submitted Homeworks</a>
                    </li>
                    
                </ul>
            </div>

        </nav>
	  
      
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">ADD COURSE</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                                 <div id="reviews" class="carousel slide" style="background-color:#FBFBFB; border-radius: 25px;" data-ride="carousel">

                                  
										<div class="form-group input-group">
										
<form action="#adding" method="post">

<!-- <label>Title:<br>
<select class="form-control" name="select1" id="select1">
<option>chose one</option>
<?php

$query="SELECT ID,title FROM course";

$result=mysql_query($query, $connection);

while($row = mysql_fetch_row($result))
for($i=0 ;$i<count($row); $i=$i+2)
echo "<option value=".$row[0].">".$row[1]."</option>";
?>
</select>

</label><br>

<label>Teacher:<br>

<select class="form-control" name="select2" id="select2" >
<option>chose one</option>
<?php
$query2="SELECT tID,name FROM teacher";

$result2=mysql_query($query2, $connection);

while($row = mysql_fetch_row($result2))
for($i=0 ;$i<count($row); $i=$i+2)
echo "<option value=".$row[0].">".$row[1]."</option>";
?>
</select>



</label><br><br>

-->

<br>
<label>choose a course:<br>

<select name="courseteacher" id="select" class="form-control" >
<option>course name/teacher name</option>
<?php
$query="SELECT cID,tID FROM teachercourses";
$result=mysql_query($query, $connection);

$q1="SELECT title FROM course WHERE ID=";
$q2="SELECT name FROM teacher WHERE tID=";


while($row = mysql_fetch_row($result)){ //array of tID , cID

for($i=0 ;$i<count($row); $i=$i+2){
$r1=mysql_query($q1.$row[0], $connection);//name of the course
$r2=mysql_query($q2.$row[1], $connection);//name of the teacher

$e1 = mysql_fetch_row($r1);//name of the course
$e2 = mysql_fetch_row($r2);//name of the teacher

echo "<option>".$e1[0]." by ".$e2[0]."</option>";}
}
?>
</select>



<div id="aading">
<?php
if(isset($_POST["add"])){

$add=$_POST["courseteacher"];
if($add=="course name/teacher name")
$message="invalid choice";

else{
$s=strpos($add," by ");
$course=substr($add,0,$s);
$teacher=substr($add,$s+4);

//course id
$q1="select ID from course where title='$course'";
$resultc=mysql_query($q1, $connection);
$row1 = mysql_fetch_assoc($resultc);
$courseid =$row1['ID'];

$q2="select tID from teacher where name='$teacher'";
$resultt=mysql_query($q2, $connection);
$row2 = mysql_fetch_assoc($resultt);
$teacherid =$row2['tID'];

//check if the course is added before
$check=true;
$checkq="select cID from studentcourses where sID=".$id;
$res=mysql_query($checkq, $connection);
while($rows = mysql_fetch_assoc($res))
if($rows['cID']==$courseid)
$check=false;

if($check==false)
$message="you have added this course before";

else{



$check2=true;
$checkq2="select cID from request where sID=".$id;
$res2=mysql_query($checkq2, $connection);
while($rows2 = mysql_fetch_assoc($res2))
if($rows2['cID']==$courseid)
$check2=false;

if($check2==false)
$message="you have send a request for this course before";

else{
// send request
$req="INSERT INTO `request` (`sID`, `tID` , `cID`) VALUES (".$id.",".$teacherid.",".$courseid.")";

if(mysql_query($req, $connection)){
$message="Your request send successfully ...";}}
}

}
}
?></div>
<br><br>
 <p class="help-block"><?php print $message; ?></p>



</label><br><br>


<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal" name="add" >Add</button>
<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal"><a href="StudentHomePage.php" style="text-decoration:none; color:white;">Back</a></button>


</form>                           
             </div>
                                        


                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>