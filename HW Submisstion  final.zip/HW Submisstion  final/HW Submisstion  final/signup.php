<?php
 session_start(); 
  $error = '';
// Includes Login Script
if (isset($_POST['submit'])) {
	
$username = mysql_escape_string($_POST['username']);
$password= mysql_escape_string($_POST['password']);
$cpassword= mysql_escape_string($_POST['cpassword']);
$status= mysql_escape_string($_POST['status']);
$Email = mysql_escape_string( $_POST['Email']);
$Name =  mysql_escape_string($_POST['name']);

//$pattern = ' ^.*(?=.{7,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).*$ ^ ';


if ($password==$cpassword ){

if(!($connection = mysql_connect("localhost", "root", "")))
die ("couuld not connect to database");


// Selecting Database
if(!($db = mysql_select_db("homeworks", $connection)))
die ("could not find database");
 
 if($status=='Student')
 $q="select * from student where username='$username' AND username='$Email'" ;
else if($status=='Teacher')
 $q="select * from teacher where username='$username' AND username='$Email'" ;


$query = mysql_query($q, $connection);
$rows = mysql_num_rows($query);

   if ($rows != 1) {
      if($status=='Student'){
mysql_query( "INSERT INTO `student`(`sID`, `name`, `email`, `username`, `password`, `pic`) VALUES ('','$Name', '$Email', '$username' , '$password' , '')");
 header("location: Studenthomepage.php");}
 else if($status=='Teacher'){
 mysql_query("INSERT INTO `teacher`(`tID`, `name`, `email`, `username`, `password`, `pic`) VALUES ('', '$Name','$Email','$username','$password','')");
  header("location: teacherHomephp.php");}} // Redirecting To Other Page
          

  else {
  $error = "Username or Email is is token";
}}
 else {
  $error = "The passwords do not match the password must have at lesst one cabital and smole sptimf";
}}


// SQL query to fetch information of registerd users and finds user match.



		    
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SignUp</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="">Homework Submission System </a>
            </div>

            <div class="header-right">

           

            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                  
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Sign Up </h1>
                        <h1 class="page-subhead-line">Enter your information to signUp </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                            </div>
							
							
							
							
							
<div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           SINGUP FORM
                        </div>
                        <div class="panel-body">
                            <form role="form" action = "signup2.php" method = "POST">
                                  <p class="help-block"><?php print $error; ?></p>      
                                 <div class="form-group">
								 
								     <label>Enter Name </label>
                                            <input class="form-control" type="text" name = "name">
                                    
								 
								   <label>Enter UserName </label>
                                            <input class="form-control" type="text" name = "username" >
                                     
								 
								 
								 
                                            <label>Enter Email</label>
                                            <input class="form-control" type="text" name = "Email">
                                    
                                        </div>
                                            <div class="form-group">
                                            <label>Enter Password</label>
                                            <input class="form-control" type="password" name = "password">
                                  
                                        </div>
										      <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input class="form-control" type="password" name = "cpassword">
                                    
                                        </div>
                               
							   
							          <div class="form-group input-group">
                                        Status:<select class="form-control" name = "status" >
										<option>Student</option>
										<option>Teacher</option></select>	</div >	
							   
							   
                                 
                                        <button type="submit" class="btn btn-danger" name = "submit">Register Now </button>

                                    </form>
                            </div>
                        </div>
                            </div>
        </div>
             <!--/.ROW-->
            
			
			
			
    <div id="footer-sec">
        &copy; 2016 Homework Submission System  
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>