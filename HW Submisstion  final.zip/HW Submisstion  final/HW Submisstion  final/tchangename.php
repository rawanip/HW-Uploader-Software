<?php

include 'session.php';
 include 'connectdb.php';
 
$username=$_SESSION['username'];

	//find the name of stu  from username
		 $nameq = "select name from teacher where  username = '$username'";
		    $result=mysql_query($nameq,$connection)  ;
			  $row = mysql_fetch_assoc($result);
			   $name = $row['name'];


		
			   
			   //when submited only 
    if (isset ($_POST['name']))
	{
			$n=$_POST["name"];
$nameq =" UPDATE teacher SET name = '$n'  WHERE username = '$username'";
  $result=mysql_query($nameq,$connection)  ;	
if ($result)  
	    echo "<script type='text/javascript'>alert('updated successfully! refresh the page ')</script>";
	}		   

?>






<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Settings</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
		<div class="header-right">
		   <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>
</div>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="teacherHomephp.php">HomeWork Submissions System</a>
            </div>

            <div class="header-right">

               
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->
      
	  
	   
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="teacher.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>
  <li>
                        <a  href="teacherHomephp.php"><i ></i>Home</a>
                    </li>

                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="tchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="tchangpassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
					
                  
              
                    <li>
                        <a href="addCoursTeacher.php"><i ></i>Add Course </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href=""><i ></i>View Statictcs</a>
                    </li>
					
						
				 <li>
                        <a href="teacherCorsess.php"><i ></i>View All Courses</a>
                    </li>
				
					
					
                    
                   
               
                   
                    
                </ul>
            </div>

        </nav>
	  
	  
	  
	  
	  
        <!-- /. NAV SIDE  -->
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Settings</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                    
					
					
					   <div class="panel-heading">
                            
                        </div>
                        <div class="panel-body">
                           
						   
						     <div class="row">
                 <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                          Change Name
                        </div>
                        <div class="panel-body">
                            <form role="form" action="tchangename.php" method= "post">
                                        <div class="form-group">
                                            <label>Enter New Name</label>
                                            <input class="form-control" type="text" id="n"  name="name">
											<br><br>
                                             <input class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal"  type="submit" value="change">
                                        </div>
                                

                                    </form>
                            </div>
                        </div>
                            </div>
                
            </div>
						   
						   
					
					
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>