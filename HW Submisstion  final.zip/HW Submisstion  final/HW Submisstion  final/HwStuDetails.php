<?php

  




 
include 'session.php';
 include 'connectdb.php';
 

 //NAME - USERNAME
$username=$_SESSION['username'];
	//find the name of stu  from username
		 $nameq = "select name from student where  username = '$username'";
		    $result=mysql_query($nameq,$connection)  ;
			  $row = mysql_fetch_assoc($result);
			   $name = $row['name'];
 /////////////////////////////////////////////
 
 
 
 
 
	 
	 $date = "";
    $file = "";
	$t="";
	$grade="";
	
$_SESSION['date']= $date;
 $_SESSION['file']= $file;
 $_SESSION['title']= $t;
  $_SESSION['grade']= $grade;
 
	  
	  
	  // if the page is accsed from StuCourseHW page ("Hwid is sent through url")
	   if (isset ($_GET['ID']))
	   {
		  
	    $hID = $_GET['ID'];
	      //1.title
   $q="select title from homework where hID='$hID'";
   $result=mysql_query($q, $connection);
   $row = mysql_fetch_array($result);
   $t =$row['title'];
   
      //2.date 
	  $dq="select date from homework where hID='$hID'";
      $result2=mysql_query($dq, $connection);
      $row2 = mysql_fetch_array($result2);
      $date =$row2['date'];
	    if ($date == 0000-00-00)
		{
	  $date= "Homework is not submitted yet";
		}else
		{
			 //4.file if the date !- null then the file is submited
      $fq="select studentfile from homework where hID='$hID'";
      $result4=mysql_query($fq, $connection);
       $frow = mysql_fetch_array($result4);
          $file = $frow["studentfile"];
		}
	  //3.grade 
	  $gq="select grade from homework where hID='$hID'";
      $result3=mysql_query($gq, $connection);
      $row3 = mysql_fetch_array($result3);
      $grade =$row3['grade'];
	    if ($grade == Null)
	  $grade= "Grade not posted yet";
  
  
     
	   
	   
	   }
	 
	 

	 
	 
	
	 
	 $_SESSION['date']= $date;
	$_SESSION['file']= $file;
     $_SESSION['title']= $t;
	 $_SESSION['grade']= $grade;
	 
	 
	 

	
?>
 <!DOCTYPE html>
 
 
 <html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title> Homework Details</title>


     <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />


</head>

   <body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="StudentHomePage.php">HomeWork Submissions System</a>
            </div>

            <div class="header-right">

                               <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->
      
	  
	  
	   
	  
	  
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="student.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                     <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="stuchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="grid.html"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
                  
              
                    <li>
                        <a href="StuAllCourses.php"><i ></i>View Courses </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href="StuAddCourse.php"><i ></i>Add Course</a>
                    </li>
					
					
				
					
					
                     <li>
                        <a href="SearchHwStu.php"><i ></i>Search for Homework</a>
                    </li>
                   
               
                     
                   <li>
                        <a href="StuViewSubmitted.php"><i ></i>View Submitted Homeworks</a>
                    </li>
                    
                </ul>
            </div>

        </nav>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
        <!-- /. NAV SIDE  -->
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
				
                    <div class="col-md-12">
                        <h1 class="page-head-line"><?php echo $_SESSION["title"]; ?> </h1>
						
                        <div class="col-md-12">
						
                        <h1 class="page-head-line">Date of Submission:</h1>
                        <h1 class="page-subhead-line"> <?php echo $_SESSION["date"]; ?> </h1>
						
						 <h1 class="page-head-line">File submited:</h1>
                        <h1 class="page-subhead-line"> <?php 
						   if ($_SESSION["date"] == 0000-00-00)
						    echo "HomeWork is not submitted yet";
						else
						echo "<a href='".$_SESSION["file"]."' target='_blank'> download submitted file </a>";
						
						
						?>  </h1>
						
						 <h1 class="page-head-line">Grade:</h1>
                        <h1 class="page-subhead-line"> <?php echo $_SESSION["grade"]; ?>  </h1>

                    </div>

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                                  
				
                                        



                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
   
   
   </body>
   
   </html>