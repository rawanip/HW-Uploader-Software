 <?php
include'session.php';
$status=$_SESSION['status'];
$username=$_SESSION['username']; 
include 'connectdb.php';


$q="SELECT *  FROM `teacher` where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];

if (isset($_GET))
  {
   $IDC= $_GET["cid"];
  }






$qT="SELECT `tID`  FROM `teacher` WHERE username = '$username'";
$resultT=mysql_query($qT, $connection);
$rowT = mysql_fetch_assoc($resultT);
$IDT =$rowT['tID']; //teacher id 
$message="";
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Update Course</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="teacherHomephp.php">Home Work System Submissions</a>
            </div>

            <div class="header-right">
 <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>
               
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->
		 
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="teacher.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                    <li>
                        <a  href="teacherHomephp.php"><i ></i>Home</a>
                    </li>

                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="tchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="tchangpassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
					
                  
              
                    <li>
                        <a href="addCoursTeacher.php"><i ></i>Add Course </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href=""><i ></i>View Statictcs</a>
                    </li>
					
						
				 <li>
                        <a href="teacherCorsess.php"><i ></i>View All Courses</a>
                    </li>
				
					
					
                    
                   
               
                   
                    
                </ul>
            </div>

        </nav>
        <!-- /. NAV TOP  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">UPDATE COURSE</h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->
<form role="form" action="#updateCourse" method="POST" >

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                                <div id="reviews" class="carousel slide" data-ride="carousel">
                                       
                                    <div class="form-group input-group">
										<input name="title"class="form-control" placeholder="Course Title" type = "text" >
                                        </div>
										
										<div class="form-group input-group">
										Description:
										<textarea name="Description"class="form-control"  rows = "4" cols= "36">Course Description</textarea>
                                        </div>
										<div class="form-group input-group">
										Year:
										<input name="year" type = "number"  name = "num" value= "2016">
										</div >
										<div class="form-group input-group">
										Book:
										<input name="Book" class="form-control" placeholder="Book name " type = "text" >
                                        </div>
										
										
										<div class="form-group input-group">
                                        semester:<select name = "semester" >
										<option>First</option>
										<option>Second</option></select></div >	
										 <div id="updateCourse">
								  <?php
								    if(isset($_POST['submit'])) 
									{ 
								      if(!empty($_POST['title'])&& !empty($_POST['Description'])&&  !empty($_POST['Book']) &&!empty($_POST['year'])){										
								    

								       $title =  mysql_real_escape_string($_POST['title']);
								       $Description =   mysql_real_escape_string($_POST['Description']);
								       $Book =   mysql_real_escape_string($_POST['Book']);
								       $year =   mysql_real_escape_string( $_POST['year']);
								       if($_POST['semester']=="Second")
									 	$semester = 2;
									   else
										$semester = 1;  
									
								      mysql_query(" UPDATE course SET title = '$title' , description='".$Description."' , book= '".$Book."' ,year=".$year.",	semester='".$semester."' WHERE ID = '".$IDC."'");
                                     
								    $message="course Information Updated successfully..";
   
									}
									
									
									else
										 $message="some field are empty..";
									
									
									}
									
								 ?>	</div >  <br><br>
                                       <p class="help-block" style="color:white;"><?php print $message; ?></p>
										
				                        <button type="submit" name="submit"alue = "submission" class="btn btn-success"  data-toggle="modal" data-target="#myModal">Update</button>

                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>
</form>
                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>