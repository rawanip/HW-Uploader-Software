<?php

if(!($connection = mysql_connect("localhost", "root", "")))
die ("couuld not connect to database");


// Selecting Database

if(!($db = mysql_select_db("homeworks", $connection)))
die ("could not find database");

?>