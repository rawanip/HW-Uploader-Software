<?php
include('menu.php');


  // get course id from url
  
$id = $_GET['ID'];

    include 'connectdb.php';
      
	  // get the title of the course 
    $q="select title from course where ID='$id'";
    $result=mysql_query($q, $connection);
    $row = mysql_fetch_assoc($result);
    $title =$row['title'];

    // get course describtion 
	
    $qd="select description from course where ID='$id'";
    $result2=mysql_query($qd, $connection);
    $row2 = mysql_fetch_assoc($result2);
    $des =$row2['description'];

    // get the teacher id 
    $qt="select tID from teachercourses where cID='$id'";
    $result3=mysql_query($qt, $connection);
    $row3 = mysql_fetch_assoc($result3);
    $tid =$row3['tID'];
	
	// get teacher name from her id
	
	$qn="select name from teacher where tID='$tid'";
    $result4=mysql_query($qn, $connection);
    $row4 = mysql_fetch_assoc($result4);
    $tname =$row4['name'];
	
	
	
	
	
?>










 <!DOCTYPE html>
 
 <html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title> Course</title>


     <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />


</head>

   <body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="StudentHomePage.php">HomeWork Submissions System</a>
            </div>

			 
			
			
            <div class="header-right">

                               <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</a>
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->
      
	  
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="student.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>


                      <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="stuchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="grid.html"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
					
                  
              
                    <li>
                        <a href="StuAllCourses.php"><i ></i>View Courses </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href="StuAddCourse.php"><i ></i>Add Course</a>
                    </li>
					
					
				
					
					
                     <li>
                        <a href="SearchHwStu.php"><i ></i>Search for Homework</a>
                    </li>
                   
                   <li>
                        <a href="StuViewSubmitted.php"><i ></i>View Submitted Homeworks</a>
                    </li>
                   
                    
                </ul>
            </div>

        </nav>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
        <!-- /. NAV SIDE  -->
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
				
                    <div class="col-md-12">
                        <h1 class="page-head-line"><?php echo $title ?> </h1>
						
                        <div class="col-md-12">
                        <h1 class="page-head-line">Teacher Name:</h1>
                        <h1 class="page-subhead-line"> <?php echo $tname ?> </h1>
						
						 <h1 class="page-head-line">Course Description:</h1>
                        <h1 class="page-subhead-line"> <?php echo $des ?> </h1>
						
                    </div>

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                                  
				
                                        



                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
   
   
   </body>
   
   </html>