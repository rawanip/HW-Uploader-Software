<?php

//1. HWid , CourseId --> muna 
// 2. get stuId from 1 for each stu while
//3. get dateof submission from 2
// 4. get hw deadline from 1
// 5. compare 3,4 
// display 


// get teacher name 
include('session.php');
$status=$_SESSION['status'];
$username=$_SESSION['username'];

include 'connectdb.php';


$q="select * from teacher where username='$username'";
$result=mysql_query($q, $connection);
$row = mysql_fetch_assoc($result);
$name =$row['name'];
//


 // HW INFO  (get information from viewHWTA HW INFO)
 /*    $IDC =' ';
     if(isset($_POST['IDC']))
     $IDC = $_POST['IDC'];
     
     $IDH =' ';
     if(isset($_POST['IDH']))
     $IDH = $_POST['IDH'];
	
	 $Title ='';
	  if (isset($_POST['Title'])) 
	  $Title =$_POST['Title'] ;*/
     


	 
	 
 $IDH =$_GET['id'];
 $q="SELECT cID,title,sID from homework where hID=". $IDH;
$result=mysql_query($q, $connection);
$row = mysql_fetch_row($result);
$IDC=$row[0];
$sID=$row[2];
$Title=$row[1];
 

 /* get student id 2.
 
$sq="select sID from studentcourses where cID='$cID'";
$sresult=mysql_query($q, $connection);
$srow = mysql_fetch_assoc($result);
$sID =$srow['sID'];*/

?>








<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Submissions</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="teacherHomephp.php">Home Work System Submissions</a>
            </div>

            <div class="header-right">

                 <a href="Request.php" class="btn btn-info" title="Requests"><b> </b><i class="fa fa-envelope-o fa-2x"></i></a>
               
	
                <a href="logoutphp.php" class="btn btn-danger" title="Logout">Log out</i></a>
				
				

            </div>
        </nav>
        <!-- /. NAV TOP  -->
      
	     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="teacher.jpg" class="img-thumbnail" />
                                  
                            <div class="inner-text">
                              <?php echo " ".$name; ?>
                            <br />
                               
                            </div>
                        </div>

                    </li>
  <li>
                        <a  href="teacherHomephp.php"><i ></i>Home</a>
                    </li>

                   <li>
                        <a href="#"  class="active-menu-top"></i>Edit Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level collapse in">
                            <li>
                         
                                <a href="tchangename.php"><i class="fa fa-edit "></i>Change Name</a>
                            </li>
                             <li>
                                <a href="tchangpassword.php"><i class="fa fa-edit "></i>Change Password</a>
                            </li>
                            
                           
                        </ul>
                    </li>
					
					
                  
              
                    <li>
                        <a href="addCoursTeacher.php"><i ></i>Add Course </a>
                        
                    </li>
                  
				
				  
                     <li>
                        <a href=""><i ></i>View Statictcs</a>
                    </li>
					
						
				 <li>
                        <a href="teacherCorsess.php"><i ></i>View All Courses</a>
                    </li>
				
					
					
                    
                   
               
                   
                    
                </ul>
            </div>

        </nav>
	  
	  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line"> <?php echo $Title  ; echo" Homework Submissions"; ?></h1>
                       

                    </div>
                </div>
                <!-- /. ROW  -->
              
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                  
                                                
												
												<?php
												
											
									 
												
							$searchq="SELECT * FROM homework Where cID='$IDC' and title= '$Title'";
							$result=mysql_query($searchq, $connection);
                            if(!$result)
										echo "<p class='help-block'>no homeworks</p>";
									
								
									
                             else
							 {
								    $idsearch="select sID from homework where hID=";
								 
									  
								      while($row = mysql_fetch_row($result))
									  {
										  
										  
										   $resultsearch=mysql_query($idsearch.$row[0], $connection);
									                $id = mysql_fetch_row($resultsearch); // array of stu id's
										  
										  
										//HW ID 
									  $Hq =  "select hID from homework where sID = '$id[0]' and cID='$IDC'";
									  $resultsearchh=mysql_query($Hq, $connection);
									 $rowh = mysql_fetch_row($resultsearchh);
								     $hid = $rowh[0]; // specific hw id  
										  
									// get name 
									    $nq =  "select name from student where sID = '$id[0]'";
									    $resultsearch2=mysql_query($nq, $connection);
										 $row = mysql_fetch_row($resultsearch2);		 
										 $name = $row[0]; // specific name	  
										  
                                  
                                    // get date of submission  ,  to check if stu didn't submit hw
									 $dq =  "select date from homework where sID = '$id[0]' AND title='$Title'";
									 $resultsearch3=mysql_query($dq, $connection);
									 $row2 = mysql_fetch_row($resultsearch3);
								     $date = $row2[0]; //  echo $date;								   

									 
									 				// get deadline of hw 
													
										$deadq =  "select deadline from homework where sID = '$id[0]' And hID=' $hid'";
									    $resultsearch4=mysql_query($deadq, $connection);
										
										 $row3 = mysql_fetch_row($resultsearch4);
										  $deadline = $row3[0]; // specifc deadline
									 
									 
									 

                                        
										
										if ($date != 0000-00-00 ) // stu submit hw
										{
                        echo	"<div id='reviews' class='carousel slide' style='background-color:#FBFBFB' data-ride='carousel'>";
                                   echo "<div class='carousel-inner'>";
                                    echo "   <div class='item active'>";						
								 echo " <table class='col-md-10 col-md-offset-1'>";
                                            echo " <tr><td>";

                                          //check if shubmission after deadline
										     if ($date > $deadline)
	                                             echo   "<span style=' color:black;  text-decoration: line-through;  font-size: 15px; '>-".$name."</span>";
                                             else echo  "<span style='color:BLACK;  font-size: 15px;  '>".$name."</span>";
											
											 echo "<br>";											
											
											
						// print buttons 
											 
						echo "</td><td> 	<form>";
											
				echo"	<button alue = 'submission' class='btn btn-xs btn-success'  data-toggle='modal' data-target='#myModal'><a href='InsertGradeTA.php?cid=".$IDC."&sid=".$sID."&hid=".$IDH."' style='text-decoration:none; color:white;'>Grade</a></button>";
				echo"	<button alue = 'submission' class='btn btn-xs btn-success'  data-toggle='modal' data-target='#myModal'><a href='UpddateGradeTA.php?cid=".$IDC."&sid=".$sID."&hid=".$IDH."' style='text-decoration:none; color:white;'>Update</a></button>";
 				echo "	</form><td></tr> <tr><td>";
 				echo "	</form><td></tr> <tr><td>";
										
                                               
											echo"	</form><td></tr> </table>";
										echo "<br><hr>";	
											
											
											
											
											
										} // end if
										  
										  
										  
										  
									  } // end while
									  
									  
								 
								 
							 }	 // end else							 
												
												
												
												
												
												
												
												
                                            ?>
                                        </div>
                                    </div>
                                    <!--INDICATORS-->
                                    
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


                
                <!--/.Row-->
                
                
                <!--/.Row-->
               
                
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 KSU 
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>